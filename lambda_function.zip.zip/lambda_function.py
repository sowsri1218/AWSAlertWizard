ECHO is on.
import json
import boto3
import requests
from datetime import datetime

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('WeatherData')

def lambda_handler(event, context):
    # Fetch weather data from Open-Meteo API
    latitude = 49.25  # Example for Burnaby, BC
    longitude = -123.12
    url = f'https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&daily=temperature_2m_max,precipitation_sum&timezone=auto'

    response = requests.get(url)
    
    if response.status_code == 200:
        weather_data = response.json()
        daily_data = weather_data['daily']
        
        # Extract relevant fields
        for i in range(len(daily_data['time'])):
            date = daily_data['time'][i]
            temp = daily_data['temperature_2m_max'][i]
            precipitation = daily_data['precipitation_sum'][i]
            
            # Store data in DynamoDB
            table.put_item(
                Item={
                    'Date': date,
                    'TemperatureMax': str(temp),
                    'PrecipitationSum': str(precipitation)
                }
            )
        return {
            'statusCode': 200,
            'body': json.dumps('Weather data stored successfully!')
        }
    else:
        return {
            'statusCode': response.status_code,
            'body': json.dumps('Failed to fetch weather data')
        }
